//GraphType from chapter 9 of the textbook
//to make the class easier to deal with, all VertexType was replaced with string
//and vertices were named to cities to understand what each function is doing actually

#include"QueType.h"

using namespace std;

class GraphType  //change the graphtype to deal with strings directly
{
public:
	GraphType();
	~GraphType();
	void MakeEmpty();
	bool IsEmpty() const;
	bool IsFull() const;
	void AddCity(string);
	void AddEdge(string fromCity, string toCity, int weight);
	int GetWeight(string fromCity, string toCity);
	void GetToCities(string, QueType&);
	void GraphType::CityChecker(string cityCheck, bool& found);

	
private:
	int numCities;
	int maxCities;
	string* cities;
	int edges[50][50];  //book had a limit of 50 for there graph, I have adopted that here
	bool found;
	int counter;  //counter made to track how many time print is to be called
};