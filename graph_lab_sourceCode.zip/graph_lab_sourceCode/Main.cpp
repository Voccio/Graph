#include<iostream>
#include<string>
#include<conio.h>
#include"GraphType.h"





int main ()
{
	using namespace std;

	void premadeGraph(GraphType& cityGraph);  //a function to create the premade graph of cities, prototype

	QueType cityQue;  //declariations for functionality
	GraphType cityGraph;
	string cityNameA;
	string cityNameB;
	char menu;
	int distanceWeight;
	char yesNo;




	do
	{
		cout << "What would you like to do." << endl;  //menu options
		cout << "a. Create the premade flight graph, SPECIAL COMMAND." << endl;
		cout << "b. Start a flight graph or add another city to the current graph." << endl;
		cout << "c. Connect two cities already in the flight graph with a distance between them." << endl;
		cout << "d. Find the distance between 2 connected cities." << endl;
		cout << "e. List all connected cities from an entered city." << endl;
		cout << "f. Clear the graph of flights and start again." << endl;
		cout << "g. Is the graph empty?" << endl;
		cout << "h. Is the graph full?" << endl;
		cout << "i. Exit the program." << endl;
		cin >> menu;
	
		

		
		switch(menu)
		{
		case 'a':
			cout << "A graph from the lab instructions will be created." << endl;
			premadeGraph(cityGraph);  //call function to create premade graph of cities
			break;
		case 'b':  //user wants to add a city to the graph
			cout << "Enter a name of a city." << endl;
			cin.ignore();
			getline(cin, cityNameA);  //new city name
			cityGraph.AddCity(cityNameA);  //add city to graph
			cout << "Is this city have a connected flight to a city already in the current graph?" << endl;  //if this city is connected why not do this now
			cout << "Enter y for yes or n for no." << endl;
			cin >> yesNo;
			if(yesNo == 'y')
			{
				cout << "To what city is this city connected too?" << endl;
				cin.get();
				getline(cin, cityNameB);
				cout << "Enter the distance between them, in interger form only please." << endl;
				cin >> distanceWeight;
				cityGraph.AddEdge(cityNameA, cityNameB, distanceWeight);
			}
			else if(yesNo != 'y')
			{}
			break;
		case 'c':  //user wants to add an edge between two cities on the graph
			cout << "Enter the name of the starting city." << endl;
			cin.get();
			getline(cin, cityNameA);
			cout << "Enter the name of the ending city." << endl;
			getline(cin, cityNameB);
			cout << "Enter the distance between this city and the next city." << endl << "In integer form only please." << endl;
			cin >> distanceWeight;
			cityGraph.AddEdge(cityNameA, cityNameB, distanceWeight);  //add the edge between the 2 inputted cities
			break;
		case 'd':  //user wants to know the weight between 2 cities
			cout << "Enter name of city to start from." << endl;
			cin.get();
			getline(cin, cityNameA);
			cout << "Enter name of the city to end in." << endl;
			getline(cin, cityNameB);
			if(cityGraph.GetWeight(cityNameA, cityNameB) != 0)
				cout << (cityGraph.GetWeight(cityNameA, cityNameB));
			else if(cityGraph.GetWeight(cityNameA, cityNameB) == 0)
				cout << "No flights go from " << cityNameA << " to " << cityNameB << "." << endl;
			break;
		case 'e':  //user wants to know all the adjacent cities from the city of their choice
			cout << "Enter the name of the city that you want to see all conecting flights from." << endl;
			cin.get();
			getline(cin, cityNameA);
			cityQue.makeEmpty();  //make the que empty so the contents from a previous que aren't in the printed outcome
			cityGraph.GetToCities(cityNameA, cityQue);
			break;
		case 'f':  //user wants the graph empty
			cout << "The flight graph will now be cleared of all previous city information." << endl;
			cityGraph.MakeEmpty();
			break;
		case 'g':  //user wants to know if the graph is empty
			if(cityGraph.IsEmpty())
				cout << "The flight graph is currently empty." << endl;
			else
				cout << "The flight graph isn't currently empty." << endl;
			break;
		case 'h':  //user wants to know if the graph is full
			if(cityGraph.IsFull())
				cout << "The flight graph is currently full." << endl;
			else
				cout << "The flight graph isn't currently full." << endl;
			break;
		default:
			continue;
		}
		cout << endl;
	}
	
	while(menu != 'i');
	cout << endl << "Please press any key to exit ..." << endl;
	cin.sync();
	_getch();
	return 0;
}




void premadeGraph(GraphType& cityGraph)  //premade function to input all the cities and weights into the graph as per instructions
{
	cityGraph.AddCity("Austin");
	cityGraph.AddCity("Chicago");
	cityGraph.AddCity("Dallas");
	cityGraph.AddCity("Denver");
	cityGraph.AddCity("Atlanta");
	cityGraph.AddCity("Houston");
	cityGraph.AddCity("Washington");
	cityGraph.AddEdge("Austin", "Dallas", 200);
	cityGraph.AddEdge("Dallas", "Austin", 200);
	cityGraph.AddEdge("Austin", "Houston", 160);
	cityGraph.AddEdge("Dallas", "Denver", 780);
	cityGraph.AddEdge("Dallas", "Chicago", 900);
	cityGraph.AddEdge("Denver", "Chicago", 1000);
	cityGraph.AddEdge("Chicago", "Denver", 1000);
	cityGraph.AddEdge("Denver", "Atlanta", 1400);
	cityGraph.AddEdge("Atlanta", "Houston", 800);
	cityGraph.AddEdge("Houston", "Atlanta", 800);
	cityGraph.AddEdge("Atlanta", "Washington", 600);
	cityGraph.AddEdge("Washington", "Atlanta", 600);
	cityGraph.AddEdge("Washington", "Dallas", 1300);
}