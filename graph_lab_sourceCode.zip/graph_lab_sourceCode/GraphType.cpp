#include"GraphType.h"

GraphType::GraphType()
{
	numCities = 0;
	maxCities = 50;
	cities = new string[50];  //limit of 50 cities
	found = false;
}

GraphType::~GraphType()
{
	delete [] cities;
}

bool GraphType::IsFull() const
{
	if(numCities == maxCities)
		return true;
	else
		return false;
}

bool GraphType::IsEmpty() const
{
	if(numCities == NULL)
		return true;
	else
		return false;
}

const int NULL_EDGE = 0;

void GraphType::AddCity(string newCity)  //the function add a new city to the graph
{
	if(IsFull())
		cout << "The flight graph is full." << endl;
	else
	{
		CityChecker(newCity, found);  //function to catch errors
		if(!found)
		{
			cities[numCities] = newCity;
			for(int index = 0; index < numCities; index++)
			{
				edges[numCities][index] = NULL_EDGE;
				edges[index][numCities] = NULL_EDGE;
			}
			numCities++;
			AddEdge(newCity, newCity, NULL_EDGE);  //any time we add a city, I wanted to declare the weight between a city and itself to be 0
		}
		else
			cout << "You have entered a city that is already on the flight graph." << endl;  //error message
	}
}

int IndexIs(string* cities, string city)
{
	int index = 0;

	while(!(city == cities[index]) && cities[index] != "")  //used "" as a catch of the end of city list, saw it as npos"" in the error list
		index++;
	return index;
}


void GraphType::AddEdge(string fromCity, string toCity, int weight)  //add a weight cost between 2 cities
{
	int row;
	int col;

	CityChecker(fromCity, found);  //check the first city
	if(found)
	{
		CityChecker(toCity, found);  //check the second city
		if(found)
		{
			row = IndexIs(cities, fromCity);
			col = IndexIs(cities, toCity);
			edges[row][col] = weight;
		}
		else if(!found)
			cout << "You have entered an invalid city that isn't on the flight graph." << endl;  //two error messages, one for each city input
	}
	else if(!found)
		cout << "You have entered an invalid city that isn't on the flight graph." << endl;
}

int GraphType::GetWeight(string fromCity, string toCity)  //a function to find what the current weight is between 2 cities
{
	int row;
	int col;

	CityChecker(fromCity, found);  //check first city
	if(found)
	{
		CityChecker(toCity, found);  //check second city
		if(found)
		{
			row = IndexIs(cities, fromCity);
			col = IndexIs(cities, toCity);
			return edges[row][col];
		}
		else //if(!found)
		{
			cout << "You have entered an invalid city that isn't on the flight graph." << endl;  //erropr message for both cities
			return 0;
		}
	}
	else if(!found)
	{
		cout << "You have entered an invalid city that isn't on the flight graph." << endl;
		return 0;
	}
}

void GraphType::GetToCities(string city, QueType& adjCities)  //a function to list all adjacent cities
{
	int fromIndex;
	int toIndex;
	counter = 0;

	CityChecker(city, found);  //check the city
	if(found)
	{
		fromIndex = IndexIs(cities, city);
		for(toIndex = 0; toIndex < numCities; toIndex++)
			if(edges[fromIndex][toIndex] != NULL_EDGE)
			{
				counter++;
				adjCities.Enqueue(cities[toIndex]);
			}
			cout << "These cities connect from " << city << ":" << endl;
			adjCities.PrintQue(counter);  //print the que of cities that connect to the inputted city
	}
	else if(!found)
		cout << "You have entered an invalid city that isn't on the flight graph." << endl;
}

void GraphType::MakeEmpty()
{
	delete [] cities;
	numCities = 0;
	cities = new string[50];
	found = false;
}

void GraphType::CityChecker(string cityCheck, bool& found)  //the function to check if the city inputted is contained within the graph
{
	found = false;
	for(int i = 0; i < numCities; i++)
	{
		if(!found)
			if(cityCheck == cities[i])
			{
				found = true;
			}
			else if(cityCheck != cities[i])
			{
				found = false;
			}
	}	
}